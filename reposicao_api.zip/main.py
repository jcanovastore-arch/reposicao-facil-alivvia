from typing import Any
from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="API Reposição Alivvia v4 (debug)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/calcular-compra")
async def api_calcular_compra(body: dict = Body(...)) -> Any:
    print("PAYLOAD:", body)
    return body
